const faceRect = document.querySelector(".face").getBoundingClientRect();

const cx = faceRect.x + faceRect.width / 2;
const cy = faceRect.y + faceRect.height / 2;
const coords = document.querySelector(".trackable");

draggies.forEach((item) => {
  item.on("dragEnd", function (event, pointer) {
    const rect = event.target.getBoundingClientRect();
    const dx = rect.x + rect.width / 2;
    const dy = rect.y + rect.height / 2;
    const dist = Math.hypot(cx - dx, cy - dy);
    console.log(dist);
    console.log(rect);

    if (dist < 250) {
      event.target.classList.add("inuse");
      event.target.style.width = "100%";
    } else {
      event.target.classList.remove("inuse");
    }
  });
});
